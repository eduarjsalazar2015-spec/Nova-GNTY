# NOVA GNTY

Proyecto inicial de una asistente de IA web, con interfaz preparada para empaquetarse con Capacitor.

## Qué incluye

- Interfaz adaptable a móvil y escritorio.
- Conversaciones guardadas localmente en el navegador.
- Chat con un proveedor compatible con OpenAI Chat Completions.
- Envío de una imagen para análisis, si el modelo elegido admite visión.
- Solicitud de generación de imágenes, si el proveedor y el modelo elegidos lo admiten.
- Dictado por voz y lectura en voz alta cuando el navegador/dispositivo ofrece esas funciones.
- Configuración base de Capacitor para Android.

## Importante antes de empezar

Este proyecto es una base inicial, no una app publicada ni probada en todos los dispositivos. La clave API no se incluye. Los modelos, la visión y la generación de imágenes dependen del proveedor, la cuenta, el saldo y los permisos disponibles.

## Ejecutar en un ordenador

Necesitas Node.js 18 o posterior.

1. Descomprime el proyecto.
2. Abre una terminal en la carpeta `nova-gnty`.
3. Instala dependencias:

   ```bash
   npm install
   ```

4. Copia `.env.example` como `.env`.
5. Edita `.env` en tu ordenador y configura tu proveedor y clave API. Nunca compartas el archivo `.env` ni lo subas a GitHub.
6. Arranca el servidor:

   ```bash
   npm start
   ```

7. Abre `http://localhost:3000` en el navegador del ordenador.

## Costes

No necesitas pagar para descargar o editar estos archivos. Las llamadas a proveedores de IA pueden costar dinero y algunos proveedores no ofrecen saldo gratuito. Revisa sus precios y límites antes de usar una clave.

## Android y Play Store

Capacitor empaqueta la interfaz web; no convierte automáticamente `server.js` en un servidor que se ejecute dentro del APK. Para que el APK se conecte a la IA, el backend debe estar desplegado en un servidor HTTPS accesible, y `API_BASE_URL` al principio de `public/app.js` debe apuntar a esa URL. No pongas la clave API en `app.js`.

Para preparar Android en un ordenador con Android Studio:

```bash
npm install
npx cap add android
npx cap sync
npx cap open android
```

Luego usa Android Studio para compilar y probar. La publicación requiere cumplir los requisitos vigentes de Google Play, pruebas, privacidad y verificación de la cuenta. No publiques el backend abierto a cualquiera sin límites de uso, autenticación y protección contra abuso.

## Limitaciones conocidas

- El reconocimiento de voz depende del navegador y puede requerir permisos y conexión.
- El análisis de imágenes requiere un modelo de texto que admita visión.
- La generación de imágenes requiere un endpoint compatible con `/images/generations`; no todos los proveedores/modelos lo admiten.
- El historial se guarda en el almacenamiento local del dispositivo y puede borrarse al limpiar los datos del navegador.
- Antes de ponerla a disposición pública, añade autenticación, límites de solicitudes, controles de coste, política de privacidad y pruebas de seguridad.
