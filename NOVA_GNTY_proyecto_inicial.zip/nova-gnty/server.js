const express = require('express');
const cors = require('cors');
const path = require('path');
require('dotenv').config();

const app = express();
const PORT = Number(process.env.PORT || 3000);
const API_BASE_URL = (process.env.AI_API_BASE_URL || 'https://api.openai.com/v1').replace(/\/+$/, '');
const TEXT_MODEL = process.env.AI_TEXT_MODEL || 'gpt-4o-mini';
const IMAGE_MODEL = process.env.AI_IMAGE_MODEL || 'dall-e-3';
const API_KEY_PLACEHOLDER = 'PEGA_TU_CLAVE_SOLO_EN_EL_ARCHIVO_LOCAL_.env';

const SYSTEM_PROMPT = `Eres NOVA GNTY, una asistente de inteligencia artificial amable, clara y curiosa.
- Responde por defecto en español, salvo que la persona pida otro idioma.
- Para tareas escolares, explica el razonamiento paso a paso y ayuda a aprender, no solo a copiar.
- Si no sabes algo o no puedes verificarlo, dilo con honestidad.
- Sé útil, respetuosa y directa.`;

const allowedOrigins = (process.env.ALLOWED_ORIGINS || '')
  .split(',')
  .map(value => value.trim())
  .filter(Boolean);

app.disable('x-powered-by');
app.use(cors({
  origin(origin, callback) {
    // Permite llamadas sin Origin en herramientas locales y solicitudes del mismo origen.
    if (!origin || allowedOrigins.length === 0 || allowedOrigins.includes(origin)) {
      return callback(null, true);
    }
    return callback(new Error('Origen no permitido por CORS.'));
  }
}));
app.use(express.json({ limit: '15mb' }));
app.use(express.static(path.join(__dirname, 'public')));

function configuredKey() {
  const key = process.env.AI_API_KEY;
  return Boolean(key && key !== 'tu_api_key_aqui' && key !== API_KEY_PLACEHOLDER);
}

function safeErrorMessage(data, statusText) {
  return data?.error?.message || statusText || 'El proveedor rechazó la solicitud.';
}

app.get('/api/status', (_req, res) => {
  res.json({
    hasApiKey: configuredKey(),
    providerUrl: API_BASE_URL,
    model: TEXT_MODEL,
    imageModel: IMAGE_MODEL
  });
});

app.post('/api/chat', async (req, res) => {
  if (!configuredKey()) {
    return res.status(503).json({
      error: 'Servicio no configurado',
      message: 'Falta una clave válida en el archivo .env del servidor.'
    });
  }

  const { messages, imageBase64 } = req.body || {};
  if (!Array.isArray(messages) || messages.length === 0 || messages.length > 40) {
    return res.status(400).json({ error: 'Envía entre 1 y 40 mensajes.' });
  }

  const payloadMessages = [{ role: 'system', content: SYSTEM_PROMPT }];

  for (let i = 0; i < messages.length; i++) {
    const msg = messages[i];
    if (!msg || typeof msg.content !== 'string') {
      return res.status(400).json({ error: 'Cada mensaje debe tener contenido de texto.' });
    }

    const role = msg.role === 'assistant' ? 'assistant' : 'user';
    const isLastUserMessage = i === messages.length - 1 && role === 'user';

    if (isLastUserMessage && typeof imageBase64 === 'string' && imageBase64.startsWith('data:image/')) {
      payloadMessages.push({
        role: 'user',
        content: [
          { type: 'text', text: msg.content || 'Describe esta imagen.' },
          { type: 'image_url', image_url: { url: imageBase64 } }
        ]
      });
    } else {
      payloadMessages.push({ role, content: msg.content });
    }
  }

  try {
    const response = await fetch(`${API_BASE_URL}/chat/completions`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${process.env.AI_API_KEY}`
      },
      body: JSON.stringify({
        model: TEXT_MODEL,
        messages: payloadMessages,
        temperature: 0.7,
        max_tokens: 1500
      })
    });

    const data = await response.json().catch(() => ({}));
    if (!response.ok) {
      return res.status(response.status).json({
        error: 'Error del proveedor de IA',
        message: safeErrorMessage(data, response.statusText)
      });
    }

    const reply = data.choices?.[0]?.message?.content;
    return res.json({ reply: typeof reply === 'string' ? reply : 'No se obtuvo una respuesta.' });
  } catch (error) {
    console.error('Chat provider error:', error.message);
    return res.status(502).json({
      error: 'Error de conexión',
      message: 'No se pudo contactar al proveedor. Comprueba la conexión y la configuración del servidor.'
    });
  }
});

app.post('/api/generate-image', async (req, res) => {
  if (!configuredKey()) {
    return res.status(503).json({
      error: 'Servicio no configurado',
      message: 'La generación de imágenes necesita una clave válida y un proveedor compatible.'
    });
  }

  const prompt = typeof req.body?.prompt === 'string' ? req.body.prompt.trim() : '';
  if (!prompt || prompt.length > 2000) {
    return res.status(400).json({ error: 'Escribe una descripción de entre 1 y 2000 caracteres.' });
  }

  try {
    const response = await fetch(`${API_BASE_URL}/images/generations`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${process.env.AI_API_KEY}`
      },
      body: JSON.stringify({
        model: IMAGE_MODEL,
        prompt,
        n: 1,
        size: '1024x1024'
      })
    });

    const data = await response.json().catch(() => ({}));
    if (!response.ok) {
      return res.status(response.status).json({
        error: 'Error al generar la imagen',
        message: safeErrorMessage(data, response.statusText)
      });
    }

    const imageUrl = data.data?.[0]?.url;
    if (!imageUrl) {
      return res.status(502).json({
        error: 'Respuesta inesperada',
        message: 'El proveedor no devolvió una URL de imagen compatible.'
      });
    }
    return res.json({ imageUrl });
  } catch (error) {
    console.error('Image provider error:', error.message);
    return res.status(502).json({
      error: 'Fallo de red',
      message: 'No se pudo contactar al proveedor de imágenes.'
    });
  }
});

app.get('*', (_req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`[NOVA GNTY] Servidor listo en http://localhost:${PORT}`);
});
