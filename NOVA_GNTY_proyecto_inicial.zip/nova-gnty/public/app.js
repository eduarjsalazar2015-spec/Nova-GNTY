(() => {
  'use strict';

  // Si la app Android usa un servidor alojado, escribe aquí su URL HTTPS,
  // por ejemplo: https://tu-servidor.example.com
  // Déjalo vacío para desarrollo web en el mismo origen.
  const API_BASE_URL = '';

  const state = {
    sessions: {},
    currentSessionId: null,
    attachedImageBase64: null,
    mode: 'chat',
    voiceEnabled: true,
    selectedVoice: null,
    recognition: null,
    listening: false,
    busy: false
  };

  const $ = id => document.getElementById(id);
  const el = {
    chatViewport: $('chatViewport'), messagesList: $('messagesList'), welcomeCard: $('welcomeCard'),
    userInput: $('userInput'), btnSend: $('btnSend'), btnMic: $('btnMic'), fileInput: $('fileInput'),
    attachmentPreview: $('attachmentPreview'), imgThumb: $('imgThumb'), btnRemoveAttachment: $('btnRemoveAttachment'),
    btnNewChat: $('btnNewChat'), btnToggleSpeech: $('btnToggleSpeech'), statusDot: $('statusDot'),
    statusLabel: $('statusLabel'), btnModeChat: $('btnModeChat'), btnModeGenImg: $('btnModeGenImg'),
    btnOpenHistory: $('btnOpenHistory'), btnCloseHistory: $('btnCloseHistory'), historyBackdrop: $('historyBackdrop'),
    historyList: $('historyList'), btnOpenSettings: $('btnOpenSettings'), btnCloseSettings: $('btnCloseSettings'),
    settingsModal: $('settingsModal'), cfgServerStatus: $('cfgServerStatus'), cfgModel: $('cfgModel'),
    selectVoice: $('selectVoice'), toastNotification: $('toastNotification')
  };

  const apiUrl = path => `${API_BASE_URL}${path}`;

  function showToast(message) {
    el.toastNotification.textContent = message;
    el.toastNotification.classList.remove('hidden');
    window.clearTimeout(showToast.timer);
    showToast.timer = window.setTimeout(() => el.toastNotification.classList.add('hidden'), 3000);
  }

  function setStatus(text, type = 'idle') {
    el.statusLabel.textContent = text;
    el.statusDot.className = 'status-dot' + (type === 'ready' ? ' ready' : type === 'error' ? ' error' : '');
  }

  function saveSessions() {
    try { localStorage.setItem('nova_gnty_sessions', JSON.stringify(state.sessions)); }
    catch { showToast('El almacenamiento está lleno. Prueba a borrar conversaciones antiguas.'); }
  }

  function loadSessions() {
    try {
      const stored = JSON.parse(localStorage.getItem('nova_gnty_sessions') || '{}');
      if (stored && typeof stored === 'object' && !Array.isArray(stored)) state.sessions = stored;
    } catch { state.sessions = {}; }
  }

  function createNewSession() {
    const id = `session_${Date.now()}`;
    state.sessions[id] = { id, title: 'Nueva conversación', messages: [] };
    state.currentSessionId = id;
    saveSessions();
    renderMessages();
    renderHistory();
  }

  function currentSession() { return state.sessions[state.currentSessionId]; }

  function switchSession(id) {
    if (!state.sessions[id]) return;
    state.currentSessionId = id;
    renderMessages();
    renderHistory();
    el.historyBackdrop.classList.add('hidden');
  }

  function escapeHtml(value) {
    return String(value).replace(/[&<>"']/g, char => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
    })[char]);
  }

  function renderMessages() {
    const session = currentSession();
    el.messagesList.replaceChildren();
    const hasMessages = Boolean(session && session.messages.length);
    el.welcomeCard.classList.toggle('hidden', hasMessages);
    if (!hasMessages) return;

    session.messages.forEach((message, index) => {
      const row = document.createElement('article');
      row.className = `msg-row ${message.role === 'user' ? 'user' : 'assistant'}`;

      if (message.image) {
        const img = document.createElement('img');
        img.className = 'msg-attached-img';
        img.alt = 'Imagen adjunta';
        img.src = message.image;
        row.appendChild(img);
      }
      if (message.generatedImage) {
        const img = document.createElement('img');
        img.className = 'generated-ai-img';
        img.alt = 'Imagen generada por IA';
        img.src = message.generatedImage;
        img.loading = 'lazy';
        row.appendChild(img);
      }
      if (message.content) {
        const bubble = document.createElement('div');
        bubble.className = 'msg-bubble' + (message.isError ? ' error' : '');
        bubble.textContent = message.content;
        row.appendChild(bubble);
      }

      const actions = document.createElement('div');
      actions.className = 'msg-actions';
      if (message.role === 'assistant' && message.content && !message.isError) {
        actions.append(
          actionButton('Copiar', 'copy', index),
          actionButton('Escuchar', 'speak', index)
        );
      } else if (message.role === 'user' && message.content) {
        actions.append(actionButton('Editar', 'edit', index));
      }
      if (actions.childElementCount) row.appendChild(actions);
      el.messagesList.appendChild(row);
    });
    el.chatViewport.scrollTop = el.chatViewport.scrollHeight;
  }

  function actionButton(label, action, index) {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'msg-action';
    button.dataset.action = action;
    button.dataset.index = String(index);
    button.textContent = label;
    return button;
  }

  async function requestJson(path, body) {
    const response = await fetch(apiUrl(path), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.message || data.details || data.error || `Error HTTP ${response.status}`);
    return data;
  }

  async function handleSend() {
    if (state.busy) return;
    const text = el.userInput.value.trim();
    const image = state.attachedImageBase64;
    if (!text && !image) return;

    const session = currentSession();
    if (!session) return;

    if (state.mode === 'image') {
      if (!text) return showToast('Describe la imagen que quieres crear.');
      session.messages.push({ role: 'user', content: `Crear imagen: ${text}` });
      session.title = session.messages.length === 1 ? text.slice(0, 36) : session.title;
      el.userInput.value = '';
      renderMessages();
      saveSessions();
      state.busy = true;
      el.btnSend.disabled = true;
      setStatus('Creando imagen…');
      try {
        const data = await requestJson('/api/generate-image', { prompt: text });
        session.messages.push({ role: 'assistant', content: `Aquí tienes la imagen solicitada.`, generatedImage: data.imageUrl });
      } catch (error) {
        session.messages.push({ role: 'assistant', content: `No pude crear la imagen: ${error.message}`, isError: true });
      } finally {
        state.busy = false;
        el.btnSend.disabled = false;
        saveSessions();
        renderMessages();
        renderHistory();
        setStatus('Sistema listo');
      }
      return;
    }

    session.messages.push({ role: 'user', content: text, image: image || null });
    if (session.messages.length === 1) session.title = (text || 'Análisis de imagen').slice(0, 36);
    el.userInput.value = '';
    clearAttachment();
    renderMessages();
    saveSessions();

    state.busy = true;
    el.btnSend.disabled = true;
    setStatus('Pensando…');
    try {
      const messages = session.messages
        .filter(m => m.role === 'user' || m.role === 'assistant')
        .map(m => ({ role: m.role, content: m.content || (m.image ? 'Analiza la imagen adjunta.' : '') }));
      const data = await requestJson('/api/chat', { messages, imageBase64: image || undefined });
      session.messages.push({ role: 'assistant', content: data.reply || 'No recibí una respuesta.' });
      if (state.voiceEnabled) speakText(data.reply || '');
    } catch (error) {
      session.messages.push({ role: 'assistant', content: `No pude conectar con la IA: ${error.message}`, isError: true });
    } finally {
      state.busy = false;
      el.btnSend.disabled = false;
      saveSessions();
      renderMessages();
      renderHistory();
      if (!('speechSynthesis' in window) || !state.voiceEnabled) setStatus('Sistema listo');
    }
  }

  function clearAttachment() {
    state.attachedImageBase64 = null;
    el.attachmentPreview.classList.add('hidden');
    el.imgThumb.removeAttribute('src');
    el.fileInput.value = '';
  }

  function handleFileSelect(event) {
    const file = event.target.files && event.target.files[0];
    if (!file) return;
    if (!file.type.startsWith('image/')) {
      showToast('Elige un archivo de imagen.');
      event.target.value = '';
      return;
    }
    if (file.size > 10 * 1024 * 1024) {
      showToast('La imagen debe pesar menos de 10 MB.');
      event.target.value = '';
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      state.attachedImageBase64 = String(reader.result);
      el.imgThumb.src = state.attachedImageBase64;
      el.attachmentPreview.classList.remove('hidden');
    };
    reader.onerror = () => showToast('No pude leer esa imagen.');
    reader.readAsDataURL(file);
  }

  function setupVoices() {
    if (!('speechSynthesis' in window)) {
      el.btnToggleSpeech.classList.add('hidden');
      return;
    }
    const fill = () => {
      const voices = window.speechSynthesis.getVoices().filter(voice => voice.lang.toLowerCase().startsWith('es'));
      el.selectVoice.replaceChildren();
      const defaultOption = document.createElement('option');
      defaultOption.value = '';
      defaultOption.textContent = voices.length ? 'Voz predeterminada del sistema' : 'Voz en español no disponible';
      el.selectVoice.appendChild(defaultOption);
      voices.forEach((voice, index) => {
        const option = document.createElement('option');
        option.value = String(index);
        option.textContent = `${voice.name} (${voice.lang})`;
        el.selectVoice.appendChild(option);
      });
      state.spanishVoices = voices;
      state.selectedVoice = voices[0] || null;
    };
    fill();
    window.speechSynthesis.onvoiceschanged = fill;
    el.selectVoice.addEventListener('change', () => {
      state.selectedVoice = state.spanishVoices?.[Number(el.selectVoice.value)] || null;
    });
  }

  function speakText(text) {
    if (!state.voiceEnabled || !('speechSynthesis' in window) || !text) return;
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text.replace(/[*#`_]/g, ''));
    utterance.lang = 'es-ES';
    utterance.rate = 1;
    if (state.selectedVoice) utterance.voice = state.selectedVoice;
    utterance.onstart = () => setStatus('Hablando…');
    utterance.onend = () => setStatus('Sistema listo');
    utterance.onerror = () => setStatus('Sistema listo');
    window.speechSynthesis.speak(utterance);
  }

  function setupRecognition() {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) {
      el.btnMic.style.opacity = '.5';
      el.btnMic.title = 'El dictado no está disponible en este navegador.';
      return;
    }
    const recognition = new SpeechRecognition();
    recognition.lang = 'es-ES';
    recognition.continuous = false;
    recognition.interimResults = false;
    state.recognition = recognition;

    recognition.onstart = () => {
      state.listening = true;
      el.btnMic.classList.add('listening');
      setStatus('Escuchando…');
    };
    recognition.onresult = event => {
      const transcript = event.results?.[0]?.[0]?.transcript || '';
      el.userInput.value = `${el.userInput.value}${el.userInput.value ? ' ' : ''}${transcript}`;
    };
    recognition.onerror = event => {
      state.listening = false;
      el.btnMic.classList.remove('listening');
      if (event.error !== 'aborted') showToast(`Micrófono: ${event.error}`);
      setStatus('Sistema listo');
    };
    recognition.onend = () => {
      state.listening = false;
      el.btnMic.classList.remove('listening');
      setStatus('Sistema listo');
    };
  }

  function toggleMic() {
    if (!state.recognition) return showToast('Este navegador no admite dictado por voz.');
    if (state.listening) {
      try { state.recognition.stop(); } catch {}
      return;
    }
    try {
      state.recognition.start();
    } catch {
      showToast('El micrófono está ocupado. Espera un momento e inténtalo de nuevo.');
    }
  }

  async function checkBackend() {
    try {
      const response = await fetch(apiUrl('/api/status'));
      if (!response.ok) throw new Error('Servidor no disponible');
      const data = await response.json();
      el.cfgServerStatus.textContent = data.hasApiKey ? 'Clave configurada' : 'Falta configurar la clave';
      el.cfgModel.textContent = data.model || 'No indicado';
      setStatus(data.hasApiKey ? 'Sistema listo' : 'Configura la IA');
      if (!data.hasApiKey) el.statusDot.classList.add('error');
    } catch {
      el.cfgServerStatus.textContent = 'No conectado';
      el.cfgModel.textContent = '—';
      setStatus('Servidor desconectado', 'error');
    }
  }

  function renderHistory() {
    el.historyList.replaceChildren();
    const sessions = Object.values(state.sessions).sort((a, b) => b.id.localeCompare(a.id));
    if (!sessions.length) {
      const p = document.createElement('p');
      p.textContent = 'Todavía no hay conversaciones guardadas.';
      p.className = 'settings-note';
      el.historyList.appendChild(p);
      return;
    }
    sessions.forEach(session => {
      const row = document.createElement('div');
      row.className = 'history-item' + (session.id === state.currentSessionId ? ' active' : '');
      const open = document.createElement('button');
      open.type = 'button';
      open.className = 'history-title';
      open.textContent = session.title || 'Conversación';
      open.addEventListener('click', () => switchSession(session.id));
      const del = document.createElement('button');
      del.type = 'button';
      del.className = 'history-delete';
      del.textContent = 'Eliminar';
      del.addEventListener('click', () => {
        delete state.sessions[session.id];
        if (state.currentSessionId === session.id) {
          const next = Object.keys(state.sessions)[0];
          if (next) state.currentSessionId = next;
          else return createNewSession();
        }
        saveSessions();
        renderMessages();
        renderHistory();
      });
      row.append(open, del);
      el.historyList.appendChild(row);
    });
  }

  function setMode(mode) {
    state.mode = mode;
    el.btnModeChat.classList.toggle('active', mode === 'chat');
    el.btnModeGenImg.classList.toggle('active', mode === 'image');
    el.userInput.placeholder = mode === 'image'
      ? 'Describe la imagen que quieres crear…'
      : 'Escribe a NOVA…';
  }

  function bindEvents() {
    el.btnSend.addEventListener('click', handleSend);
    el.userInput.addEventListener('input', () => {
      el.userInput.style.height = 'auto';
      el.userInput.style.height = `${Math.min(el.userInput.scrollHeight, 120)}px`;
    });
    el.userInput.addEventListener('keydown', event => {
      if (event.key === 'Enter' && !event.shiftKey && !event.isComposing) {
        event.preventDefault();
        handleSend();
      }
    });
    el.btnMic.addEventListener('click', toggleMic);
    el.fileInput.addEventListener('change', handleFileSelect);
    el.btnRemoveAttachment.addEventListener('click', clearAttachment);
    el.btnNewChat.addEventListener('click', createNewSession);
    el.btnModeChat.addEventListener('click', () => setMode('chat'));
    el.btnModeGenImg.addEventListener('click', () => setMode('image'));

    el.btnToggleSpeech.addEventListener('click', () => {
      state.voiceEnabled = !state.voiceEnabled;
      if (!state.voiceEnabled && 'speechSynthesis' in window) window.speechSynthesis.cancel();
      el.btnToggleSpeech.style.color = state.voiceEnabled ? 'var(--cyan)' : 'var(--muted)';
      showToast(state.voiceEnabled ? 'Voz activada' : 'Voz desactivada');
    });

    document.querySelectorAll('.suggestion').forEach(button => {
      button.addEventListener('click', () => {
        if (button.dataset.mode === 'image') {
          setMode('image');
          el.userInput.focus();
        } else {
          setMode('chat');
          el.userInput.value = button.dataset.prompt || '';
          handleSend();
        }
      });
    });

    el.messagesList.addEventListener('click', async event => {
      const button = event.target.closest('[data-action]');
      if (!button) return;
      const message = currentSession()?.messages[Number(button.dataset.index)];
      if (!message) return;
      if (button.dataset.action === 'copy') {
        try {
          await navigator.clipboard.writeText(message.content);
          showToast('Copiado.');
        } catch { showToast('No pude copiar el texto en este navegador.'); }
      } else if (button.dataset.action === 'speak') {
        speakText(message.content);
      } else if (button.dataset.action === 'edit') {
        el.userInput.value = message.content;
        el.userInput.focus();
      }
    });

    el.btnOpenHistory.addEventListener('click', () => {
      renderHistory();
      el.historyBackdrop.classList.remove('hidden');
    });
    el.btnCloseHistory.addEventListener('click', () => el.historyBackdrop.classList.add('hidden'));
    el.historyBackdrop.addEventListener('click', event => {
      if (event.target === el.historyBackdrop) el.historyBackdrop.classList.add('hidden');
    });
    el.btnOpenSettings.addEventListener('click', () => {
      checkBackend();
      el.settingsModal.classList.remove('hidden');
    });
    el.btnCloseSettings.addEventListener('click', () => el.settingsModal.classList.add('hidden'));
    el.settingsModal.addEventListener('click', event => {
      if (event.target === el.settingsModal) el.settingsModal.classList.add('hidden');
    });
  }

  function init() {
    loadSessions();
    setupVoices();
    setupRecognition();
    bindEvents();
    if (!Object.keys(state.sessions).length) createNewSession();
    else {
      state.currentSessionId = Object.keys(state.sessions).sort().at(-1);
      renderMessages();
      renderHistory();
    }
    checkBackend();
  }

  window.addEventListener('DOMContentLoaded', init);
})();
